(function (window, document) {
  'use strict';
  const CRM = window.CRM = window.CRM || {};
  
  // XATOLIKNI TO'G'RILASH: app.js bizni qidirayotganda xato bermasligi uchun obyektni darhol e'lon qilamiz
  CRM.groupsPage = { init: function() {}, render: function() {} };

  let isMounted = false;
  
  const WEEKDAYS = ['mon', 'tue', 'wed', 'thu', 'fri', 'sat', 'sun'];
  let state = { groups: [], search: '', status: 'all', course: 'all', day: 'all' };

  const i18n = {
    en: { groups: 'Groups', title: 'Groups', desc: 'Manage cohorts and schedules.', create: 'Create Group', search: 'Search groups...', total: 'Total Groups', active: 'Active', inactive: 'Inactive', students: 'Students', any_day: 'Any Day', mon: 'Mon', tue: 'Tue', wed: 'Wed', thu: 'Thu', fri: 'Fri', sat: 'Sat', sun: 'Sun', course: 'Course', status: 'Status', actions: 'Actions', save: 'Save', cancel: 'Cancel', notifications: 'Notifications', no_notifications: 'No new notifications', admin: 'Administrator', profile: 'Profile', settings: 'Settings', logout: 'Logout', study_days: 'Study Days', name: 'Group Name', teacher: 'Teacher', description: 'Description', nav_home: 'Home', nav_students: 'Students', nav_groups: 'Groups', nav_courses: 'Courses', no_results: 'No groups found', no_results_desc: 'Try adjusting your search or filters.' },
    uz: { groups: 'Guruhlar', title: 'Guruhlar', desc: 'Kohortlar va jadvallarni boshqaring.', create: 'Guruh Yaratish', search: 'Guruhlarni qidirish...', total: 'Jami Guruhlar', active: 'Faol', inactive: 'Faolsiz', students: 'O\'quvchilar', any_day: 'Barcha kunlar', mon: 'Dush', tue: 'Sesh', wed: 'Chor', thu: 'Pay', fri: 'Jum', sat: 'Shan', sun: 'Yak', course: 'Kurs', status: 'Holat', actions: 'Harakatlar', save: 'Saqlash', cancel: 'Bekor qilish', notifications: 'Bildirishnomalar', no_notifications: 'Yangi bildirishnomalar yo\'q', admin: 'Administrator', profile: 'Profil', settings: 'Sozlamalar', logout: 'Chiqish', study_days: 'Dars kunlari', name: 'Guruh nomi', teacher: 'O\'qituvchi', description: 'Tavsif', nav_home: 'Asosiy', nav_students: 'O\'quvchilar', nav_groups: 'Guruhlar', nav_courses: 'Kurslar', no_results: 'Guruhlar topilmadi', no_results_desc: 'Qidiruv yoki filtrlarni o\'zgartirib ko\'ring.' },
    ru: { groups: 'Группы', title: 'Группы', desc: 'Управление группами и расписанием.', create: 'Создать Группу', search: 'Поиск групп...', total: 'Всего Групп', active: 'Активные', inactive: 'Неактивные', students: 'Студенты', any_day: 'Любой день', mon: 'Пн', tue: 'Вт', wed: 'Ср', thu: 'Чт', fri: 'Пт', sat: 'Сб', sun: 'Вс', course: 'Курс', status: 'Статус', actions: 'Действия', save: 'Сохранить', cancel: 'Отмена', notifications: 'Уведомления', no_notifications: 'Нет новых уведомлений', admin: 'Администратор', profile: 'Профиль', settings: 'Настройки', logout: 'Выйти', study_days: 'Дни занятий', name: 'Название группы', teacher: 'Учитель', description: 'Описание', nav_home: 'Главная', nav_students: 'Студенты', nav_groups: 'Группы', nav_courses: 'Курсы', no_results: 'Группы не найдены', no_results_desc: 'Попробуйте изменить параметры поиска.' }
  };
  let currentLang = localStorage.getItem('crm-lang') || 'en';
  function t(key) { return i18n[currentLang][key] || key; }

  function setupGlobalUI() {
    const themeBtn = document.getElementById('theme-toggle');
    if (themeBtn) {
      const currentTheme = document.documentElement.getAttribute('data-theme') || 'dark';
      themeBtn.innerHTML = currentTheme === 'dark' ? '<i class="fa-solid fa-moon"></i>' : '<i class="fa-solid fa-sun"></i>';
      themeBtn.onclick = () => {
        const next = document.documentElement.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
        document.documentElement.setAttribute('data-theme', next);
        localStorage.setItem('crm-theme', next);
        themeBtn.innerHTML = next === 'dark' ? '<i class="fa-solid fa-moon"></i>' : '<i class="fa-solid fa-sun"></i>';
      };
    }

    const hamburger = document.getElementById('hamburger-btn');
    const sidebar = document.getElementById('sidebar');
    const backdrop = document.getElementById('sidebar-backdrop');
    if (hamburger && sidebar && backdrop) {
      hamburger.onclick = () => {
        const isOpen = sidebar.classList.contains('is-open');
        sidebar.classList.toggle('is-open');
        backdrop.classList.toggle('is-active');
        hamburger.setAttribute('aria-expanded', !isOpen);
      };
      // Tashqariga bosilganda yopilish
      backdrop.onclick = () => {
        sidebar.classList.remove('is-open');
        backdrop.classList.remove('is-active');
        hamburger.setAttribute('aria-expanded', 'false');
      };
    }

    document.querySelectorAll('[data-lang]').forEach(btn => {
      btn.onclick = () => {
        currentLang = btn.dataset.lang;
        localStorage.setItem('crm-lang', currentLang);
        document.querySelector('.lang-label').textContent = currentLang.toUpperCase();
        isMounted = false; 
        init();
      };
    });

    const searchInput = document.getElementById('global-search-input');
    const searchResults = document.getElementById('search-results');
    if (searchInput && searchResults) {
      searchInput.oninput = (e) => {
        const query = e.target.value.toLowerCase().trim();
        searchResults.innerHTML = '';
        if (!query) { searchResults.classList.remove('is-active'); return; }
        
        const results = state.groups.filter(g => g.name.toLowerCase().includes(query) || (g.code && g.code.toLowerCase().includes(query)));
        if (results.length > 0) {
          results.forEach(g => {
            const item = document.createElement('div');
            item.className = 'search-item';
            item.innerHTML = `<i class="fa-solid fa-layer-group"></i> <span style="flex:1; font-weight:500; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">${g.name}</span> <span class="course">${g.course}</span>`;
            item.onclick = () => {
              searchInput.value = g.name;
              searchResults.classList.remove('is-active');
              openModal(g.id);
            };
            searchResults.appendChild(item);
          });
        } else {
          searchResults.innerHTML = `<div class="search-item" style="color:var(--text-secondary); cursor:default; justify-content:center;">${t('no_results')}</div>`;
        }
        searchResults.classList.add('is-active');
      };

      document.addEventListener('click', (e) => {
        if (!e.target.closest('#search-wrapper')) searchResults.classList.remove('is-active');
      });
      document.addEventListener('keydown', (e) => {
        if ((e.ctrlKey || e.metaKey) && e.key === 'k') { e.preventDefault(); searchInput.focus(); }
        if (e.key === 'Escape') searchResults.classList.remove('is-active');
      });
    }

    // NAVBAR SCROLL EFFEKTI
    const topbar = document.getElementById('topbar');
    const contentArea = document.querySelector('.content');
    if (contentArea && topbar && !contentArea.dataset.hasScrollListener) {
      let isTicking = false;
      contentArea.addEventListener('scroll', () => {
        if (!isTicking) {
          window.requestAnimationFrame(() => {
            if (contentArea.scrollTop > 30) topbar.classList.add('is-scrolled');
            else topbar.classList.remove('is-scrolled');
            isTicking = false;
          });
          isTicking = true;
        }
      }, { passive: true });
      contentArea.dataset.hasScrollListener = 'true';
    }
  }

  function init() {
    const main = document.getElementById('main-content');
    if (!main) return;
    setupGlobalUI();

    if (isMounted) { loadData(); return; }

    renderShell(main);
    bindModuleEvents();
    loadData();
    isMounted = true;
  }

  function renderShell(main) {
    main.innerHTML = `
      <section class="groups-page">
        <header class="groups-page__header">
          <div>
            <h1 class="groups-page__title">${t('title')}</h1>
            <p class="groups-page__desc">${t('desc')}</p>
          </div>
          <button class="btn--primary" id="btn-create">
            <i class="fa-solid fa-plus"></i> <span>${t('create')}</span>
          </button>
        </header>

        <section class="groups-summary">
          <div class="groups-summary__card"><div class="groups-summary__label"><i class="fa-solid fa-layer-group"></i> ${t('total')}</div><div class="groups-summary__value" id="metric-total">0</div></div>
          <div class="groups-summary__card"><div class="groups-summary__label"><i class="fa-solid fa-check-circle"></i> ${t('active')}</div><div class="groups-summary__value" id="metric-active">0</div></div>
          <div class="groups-summary__card"><div class="groups-summary__label"><i class="fa-solid fa-pause-circle"></i> ${t('inactive')}</div><div class="groups-summary__value" id="metric-inactive">0</div></div>
          <div class="groups-summary__card"><div class="groups-summary__label"><i class="fa-solid fa-users"></i> ${t('students')}</div><div class="groups-summary__value" id="metric-students">0</div></div>
        </section>

        <div class="groups-toolbar">
          <div class="groups-search"><i class="fa-solid fa-magnifying-glass"></i><input type="text" id="search-input" placeholder="${t('search')}" aria-label="${t('search')}"></div>
          <div class="groups-select">
            <label for="course-filter" class="visually-hidden">${t('course')}</label>
            <select id="course-filter"><option value="all">${t('course')}</option></select>
          </div>
          <div class="groups-select">
            <label for="day-filter" class="visually-hidden">${t('study_days')}</label>
            <select id="day-filter"><option value="all">${t('any_day')}</option>${WEEKDAYS.map(d => `<option value="${d}">${t(d)}</option>`).join('')}</select>
          </div>
          <div class="groups-select">
            <label for="status-filter" class="visually-hidden">${t('status')}</label>
            <select id="status-filter"><option value="all">${t('status')}</option><option value="active">${t('active')}</option><option value="inactive">${t('inactive')}</option></select>
          </div>
        </div>

        <div class="groups-table-wrap">
          <table class="groups-table">
            <thead><tr><th>${t('name')}</th><th>${t('course')}</th><th>${t('study_days')}</th><th>${t('teacher')}</th><th>${t('status')}</th><th style="text-align:right">${t('actions')}</th></tr></thead>
            <tbody id="groups-tbody"></tbody>
          </table>
        </div>

        <dialog class="groups-modal" id="group-modal">
          <form id="group-form" method="dialog">
            <div class="groups-modal__header">
              <h3 id="modal-title">${t('create')}</h3>
              <button type="button" class="groups-icon-btn" id="btn-close-modal" aria-label="Close modal"><i class="fa-solid fa-xmark"></i></button>
            </div>
            <div class="groups-modal__body">
              <div class="groups-form__grid">
                <input type="hidden" id="group-id">
                <div class="groups-field groups-field--full"><label for="group-name">${t('name')} <span class="text-danger">*</span></label><input type="text" id="group-name" required></div>
                <div class="groups-field"><label for="group-course">${t('course')} <span class="text-danger">*</span></label><select id="group-course" required></select></div>
                <div class="groups-field"><label for="group-teacher">${t('teacher')}</label><input type="text" id="group-teacher"></div>
                <div class="groups-field groups-field--full"><label>${t('study_days')}</label><div class="day-picker" id="day-picker-container">${WEEKDAYS.map(d => `<div class="day-chip" data-day="${d}">${t(d)}</div>`).join('')}</div></div>
                <div class="groups-field"><label for="group-status">${t('status')}</label><select id="group-status"><option value="active">${t('active')}</option><option value="inactive">${t('inactive')}</option></select></div>
                <div class="groups-field groups-field--full"><label for="group-description">${t('description')}</label><textarea id="group-description" placeholder="Optional details..."></textarea></div>
              </div>
            </div>
            <div class="groups-modal__footer">
              <button type="button" class="btn--ghost" id="btn-cancel-modal">${t('cancel')}</button>
              <button type="submit" class="btn--primary">${t('save')}</button>
            </div>
          </form>
        </dialog>
      </section>
    `;

    const courses = CRM.groupsData.getCourses();
    document.getElementById('course-filter').innerHTML += courses.map(c => `<option value="${c}">${c}</option>`).join('');
    document.getElementById('group-course').innerHTML = '<option value="">Select...</option>' + courses.map(c => `<option value="${c}">${c}</option>`).join('');
  }

  function bindModuleEvents() {
    const main = document.getElementById('main-content');
    const modal = document.getElementById('group-modal');
    
    document.getElementById('search-input').oninput = (e) => { state.search = e.target.value.toLowerCase(); renderTable(); };
    document.getElementById('course-filter').onchange = (e) => { state.course = e.target.value; renderTable(); };
    document.getElementById('status-filter').onchange = (e) => { state.status = e.target.value; renderTable(); };
    document.getElementById('day-filter').onchange = (e) => { state.day = e.target.value; renderTable(); };

    document.getElementById('day-picker-container').onclick = (e) => {
      if (e.target.classList.contains('day-chip')) e.target.classList.toggle('selected');
    };

    main.onclick = (e) => {
      const btn = e.target.closest('button');
      if (!btn) return;
      if (btn.id === 'btn-create') openModal();
      else if (btn.dataset.action === 'edit') openModal(btn.dataset.id);
      else if (btn.dataset.action === 'toggle-status') toggleStatus(btn.dataset.id);
    };

    document.getElementById('btn-close-modal').onclick = () => modal.close();
    document.getElementById('btn-cancel-modal').onclick = () => modal.close();

    document.getElementById('group-form').onsubmit = (e) => {
      e.preventDefault();
      const id = document.getElementById('group-id').value;
      const payload = {
        name: document.getElementById('group-name').value.trim(),
        course: document.getElementById('group-course').value,
        teacher: document.getElementById('group-teacher').value.trim(),
        status: document.getElementById('group-status').value,
        description: document.getElementById('group-description').value.trim(),
        studyDays: Array.from(document.querySelectorAll('.day-chip.selected')).map(c => c.dataset.day)
      };
      
      if (!payload.name || !payload.course) return alert('Fill required fields');
      
      const req = id ? CRM.groupsData.update(id, payload) : CRM.groupsData.create(payload);
      req.then(() => { modal.close(); loadData(); }).catch(err => alert(err.message));
    };
  }

  function loadData() {
    CRM.groupsData.list().then(data => {
      state.groups = data; updateMetrics(); renderTable();
    });
  }

  function updateMetrics() {
    const total = state.groups.length;
    const active = state.groups.filter(g => g.status === 'active').length;
    const students = state.groups.reduce((sum, g) => sum + (g.studentCount || 0), 0);
    document.getElementById('metric-total').textContent = total;
    document.getElementById('metric-active').textContent = active;
    document.getElementById('metric-inactive').textContent = total - active;
    document.getElementById('metric-students').textContent = students;
  }

  function renderTable() {
    const tbody = document.getElementById('groups-tbody');
    tbody.innerHTML = '';

    const filtered = state.groups.filter(g => {
      const matchSearch = g.name.toLowerCase().includes(state.search) || (g.code && g.code.toLowerCase().includes(state.search));
      const matchStatus = state.status === 'all' || g.status === state.status;
      const matchCourse = state.course === 'all' || g.course === state.course;
      const matchDay = state.day === 'all' || (g.studyDays && g.studyDays.includes(state.day));
      return matchSearch && matchStatus && matchCourse && matchDay;
    });

    if (filtered.length === 0) {
      tbody.innerHTML = `<tr><td colspan="6"><div style="text-align:center; padding:3rem; color:var(--text-secondary);"><i class="fa-solid fa-magnifying-glass" style="font-size:2rem; margin-bottom:1rem; opacity:0.5;"></i><h4 style="color:var(--text-primary);">${t('no_results')}</h4></div></td></tr>`;
      return;
    }

    filtered.forEach(g => {
      const tr = document.createElement('tr');
      const daysHtml = g.studyDays && g.studyDays.length 
        ? g.studyDays.map(d => `<span style="font-size:0.75rem; padding:4px 8px; background:var(--surface-hover); border-radius:var(--radius-sm); margin-right:4px;">${t(d)}</span>`).join('') 
        : '-';
      
      tr.innerHTML = `
        <td><div class="groups-entity"><div class="groups-avatar">${g.name.substring(0, 2).toUpperCase()}</div><div><span class="groups-entity__name">${g.name}</span><span class="groups-entity__code">${g.code || 'N/A'}</span></div></div></td>
        <td>${g.course}</td>
        <td>${daysHtml}</td>
        <td>${g.teacher || '-'}</td>
        <td><span class="groups-status groups-status--${g.status}"><span style="display:inline-block; width:6px; height:6px; border-radius:50%; background:currentColor; margin-right:4px;"></span> ${t(g.status)}</span></td>
        <td style="text-align:right;">
          <button class="groups-icon-btn" data-action="edit" data-id="${g.id}" aria-label="Edit"><i class="fa-solid fa-pen"></i></button>
          <button class="groups-icon-btn" data-action="toggle-status" data-id="${g.id}" aria-label="Toggle Status"><i class="fa-solid fa-power-off"></i></button>
        </td>
      `;
      tbody.appendChild(tr);
    });
  }

  function openModal(id = null) {
    const modal = document.getElementById('group-modal');
    const form = document.getElementById('group-form');
    form.reset();
    document.querySelectorAll('.day-chip').forEach(c => c.classList.remove('selected'));

    if (id) {
      const group = state.groups.find(g => g.id === id);
      if (group) {
        document.getElementById('modal-title').textContent = 'Edit Group';
        document.getElementById('group-id').value = group.id;
        document.getElementById('group-name').value = group.name;
        document.getElementById('group-course').value = group.course;
        document.getElementById('group-teacher').value = group.teacher || '';
        document.getElementById('group-status').value = group.status;
        document.getElementById('group-description').value = group.description || '';
        if (group.studyDays) {
          group.studyDays.forEach(day => document.querySelector(`.day-chip[data-day="${day}"]`)?.classList.add('selected'));
        }
      }
    } else {
      document.getElementById('modal-title').textContent = t('create');
      document.getElementById('group-id').value = '';
    }
    modal.showModal();
  }

  function toggleStatus(id) {
    const group = state.groups.find(g => g.id === id);
    if (!group) return;
    CRM.groupsData.setStatus(id, group.status === 'active' ? 'inactive' : 'active').then(() => loadData());
  }

  // app.js uchun to'g'ri obyekt
  CRM.groupsPage = { init: init, render: init, mount: init };

  document.addEventListener('DOMContentLoaded', init);
  window.addEventListener('pageshow', (e) => { if (e.persisted) init(); });

})(window, document);