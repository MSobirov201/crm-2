(function (CRM) {
  'use strict';
  var dom = CRM.dom;

  function resolvePage() {
    var p = document.body.dataset.page;
    if (!p || p === 'auto') {
      var q = new URLSearchParams(window.location.search).get('page');
      p = q || 'dashboard';
    }
    return p;
  }

  function setToday() {
    dom.qsa('[data-widget="today"]').forEach(function (el) {
      el.textContent = CRM.format.longDate(new Date());
    });
  }

  function showToast(message) {
    var host = dom.qs('.toast-host');
    if (!host) {
      host = dom.el('div', { class: 'toast-host', role: 'status', 'aria-live': 'polite' });
      document.body.appendChild(host);
    }
    var t = dom.el('div', { class: 'toast' }, [
      dom.el('i', { class: 'fa-solid fa-circle-info', 'aria-hidden': 'true' }),
      dom.el('span', { text: message })
    ]);
    host.appendChild(t);
    requestAnimationFrame(function () { t.classList.add('is-visible'); });
    setTimeout(function () {
      t.classList.remove('is-visible');
      setTimeout(function () { t.remove(); }, 200);
    }, 2600);
  }

  function bindGlobalActions() {
    dom.on(document.body, 'click', '[data-action="coming-soon"]', function (e, btn) {
      e.preventDefault();
      var label = btn.dataset.label || 'This feature';
      showToast(label + ' is a placeholder in this preview build.');
    });

    dom.on(document.body, 'click', '[data-action="toggle-notifications"]', function (e, btn) {
      e.preventDefault();
      var open = btn.getAttribute('aria-expanded') === 'true';
      btn.setAttribute('aria-expanded', String(!open));
      showToast(open ? 'Notifications closed.' : 'Notifications panel will appear here.');
    });

    dom.on(document.body, 'click', '[data-action="toggle-user"]', function (e, btn) {
      e.preventDefault();
      var open = btn.getAttribute('aria-expanded') === 'true';
      btn.setAttribute('aria-expanded', String(!open));
      showToast(open ? 'Account menu closed.' : 'Account menu will appear here.');
    });
  }

  function init() {
    var page = resolvePage();

    if (CRM.theme) CRM.theme.init();
    CRM.navigation.render(dom.qs('#sidebar'));
    CRM.navigation.setActive(page);
    CRM.navigation.initMobile();
    CRM.topbar.render(dom.qs('#topbar'), { page: page });
    CRM.topbar.init();
    bindGlobalActions();
    setToday();

    if (page === 'dashboard') {
      CRM.kpiCards.render(dom.qs('[data-widget="kpis"]'), CRM.data.kpis);
      CRM.chart.init();
      CRM.activityFeed.init();
      CRM.recentStudents.init();
      CRM.upcomingLessons.init();
    } else if (CRM.placeholder) {
      CRM.placeholder.render(page);
    }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

  CRM.app = { showToast: showToast };
})(window.CRM);