(function (window) {
  'use strict';
  const CRM = window.CRM = window.CRM || {};

  // In-memory Database
  let groups = [
    { id: 'grp_001', name: 'Frontend A', code: 'FE-A', course: 'Frontend', teacher: 'Madina', studentCount: 18, status: 'active', studyDays: ['mon', 'wed', 'fri'], createdAt: '2024-09-12' },
    { id: 'grp_002', name: 'Backend API', code: 'BE-API', course: 'Backend', teacher: 'Dilshod', studentCount: 12, status: 'active', studyDays: ['tue', 'thu'], createdAt: '2024-08-30' },
    { id: 'grp_003', name: 'UI/UX Design', code: 'UX-01', course: 'Design', teacher: 'Zilola', studentCount: 21, status: 'inactive', studyDays: ['sat'], createdAt: '2024-10-02' },
    { id: 'grp_004', name: 'Data Science', code: 'DS-01', course: 'Data', teacher: 'Rustam', studentCount: 14, status: 'active', studyDays: ['mon', 'wed'], createdAt: '2024-07-21' }
  ];

  CRM.groupsData = {
    list: () => Promise.resolve([...groups]),
    create: (data) => {
      const record = { ...data, id: 'grp_' + Date.now(), studentCount: 0, createdAt: new Date().toISOString() };
      groups.unshift(record);
      return Promise.resolve(record);
    },
    update: (id, data) => {
      const index = groups.findIndex(g => g.id === id);
      if (index === -1) return Promise.reject(new Error('Group not found'));
      groups[index] = { ...groups[index], ...data, updatedAt: new Date().toISOString() };
      return Promise.resolve(groups[index]);
    },
    setStatus: (id, status) => {
      const index = groups.findIndex(g => g.id === id);
      if (index === -1) return Promise.reject(new Error('Group not found'));
      groups[index].status = status;
      return Promise.resolve(groups[index]);
    },
    getCourses: () => ['Frontend', 'Backend', 'Design', 'Data', 'Marketing']
  };
})(window);